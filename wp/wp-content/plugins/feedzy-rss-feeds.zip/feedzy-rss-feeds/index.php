<?php
/**
 * Nothing to do here
 *
 * @link       http://themeisle.com/plugins/feedzy-rss-feed/
 * @since      3.0.0
 *
 * @package    feedzy-rss-feeds
 */
